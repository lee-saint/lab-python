# 명령 프롬프트: pip install cx-Oracle
# PyCharm: File -> Setting -> Project -> Project Interpreter

import cx_Oracle

print(cx_Oracle.version)
